/* esm.sh - @nanostores/preact@0.5.1 */
import "/nanostores@^0.10.3?target=es2022";
import "/preact@10.19.3/es2022/hooks.mjs";
export * from "/@nanostores/preact@0.5.1/X-ZHByZWFjdEAxMC4xOS4z/es2022/preact.mjs";
