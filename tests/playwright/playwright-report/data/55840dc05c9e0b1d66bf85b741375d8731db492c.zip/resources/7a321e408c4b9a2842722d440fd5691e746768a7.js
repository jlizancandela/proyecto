/* esm.sh - preact@10.19.3 */
export * from "/preact@10.19.3/es2022/preact.mjs";
