/* esm.sh - @nanostores/preact@1.0.0 */
import "/nanostores@^1.1.0?target=es2022";
import "/preact@10.19.3/es2022/hooks.mjs";
export * from "/@nanostores/preact@1.0.0/X-ZHByZWFjdEAxMC4xOS4z/es2022/preact.mjs";
