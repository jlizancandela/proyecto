/* esm.sh - preact@10.19.3/hooks */
import "/preact@10.19.3/es2022/preact.mjs";
export * from "/preact@10.19.3/es2022/hooks.mjs";
