/* esm.sh - htm@3.1.1 */
export * from "/htm@3.1.1/es2022/htm.mjs";
export { default } from "/htm@3.1.1/es2022/htm.mjs";
